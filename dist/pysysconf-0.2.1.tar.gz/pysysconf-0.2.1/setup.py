from distutils.core import setup
setup(name = "pysysconf",
      version = "0.2.1",
      description = "Python System Configuration library",
      author = "Matt West",
      author_email = "westm@stanford.edu",
      url = "http://www.stanford.edu/~westm/code/pysysconf/",
      py_modules = ["pysysconf"],
      )
