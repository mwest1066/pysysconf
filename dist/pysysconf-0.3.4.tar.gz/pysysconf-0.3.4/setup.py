from distutils.core import setup
setup(name = "pysysconf",
      version = "0.3.4",
      description = "Python System Configuration library",
      author = "Matthew West",
      author_email = "mwest@illinois.edu",
      url = "http://lagrange.mechse.illinois.edu/mwest/pysysconf/",
      py_modules = ["pysysconf"],
      )
